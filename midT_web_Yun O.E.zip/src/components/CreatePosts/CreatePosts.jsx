import { useState } from 'react';

export const CreatePosts = ({setData}) => {
    const [name, setName] = useState('')
    const [text, setText] = useState('')
    const [image, setImage] = useState('')
    const createPost = (e) => {
        e.preventDefault()
        setData(prev => [...prev, {id: prev.length + 1, name, text, image}])
    }
    return (
        <form>
            <input
                placeholder='Name'
                onChange={e => setName(e.target.value)}
                value={name}
            />
            <input
                placeholder='Text'
                onChange={e => setText(e.target.value)}
                value={text}
            />
            <input
                placeholder='Image'
                onChange={e => setImage(e.target.value)}
                value={image}
            />
            <button onClick={e => createPost(e)}>Create post</button>
        </form>
    );
}