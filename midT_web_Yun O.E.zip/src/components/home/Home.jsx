
import { useState } from 'react';
import {data as postData} from './data'
import styles from './Home.module.css'
import { CreatePosts } from '../CreatePosts/CreatePosts';

export const Home = () => {
    const [data, setData] = useState(postData)
    return (
        <div>
            <div>
                <CreatePosts setData={setData}/>   
                <div>
                    {data.map(data => (
                        <div key= {data.id} className={styles.info}>
                            <h2>{data.name}</h2>
                            <p>{data.text}</p>
                            <img src={`${data.image}`}/>   
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}