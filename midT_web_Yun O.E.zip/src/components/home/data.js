export const data = [
    {
        id: 1,
        name: 'Oleg',
        text: 'textO',
        image: "https://media.istockphoto.com/id/1322277517/photo/wild-grass-in-the-mountains-at-sunset.jpg?s=612x612&w=0&k=20&c=6mItwwFFGqKNKEAzv0mv6TaxhLN3zSE43bWmFN--J5w=",
        likes: 0,
        dislikes: 0
    },
    {
        id: 2,
        name: 'Panda',
        text: 'textP',
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRv1_6EgOCnoYi1sxCp6puG0Y75wrG8xfwECuHckrl_Pu8U_xDNdeEBinQB8cAgpRSM4t4&usqp=CAU",
        likes: 0,
        dislikes: 0
    },
]